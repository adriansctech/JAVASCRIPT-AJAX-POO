var data = [{
    id: 1,
    name: "Peter",
    email: "peter@gmail.com",
    products: [{
        id: 1,
        description: "Bicicleta con ruedines",
        price: 56.50
    },{
        id: 2,
        description: "Bigote postizo",
        price: 5.75,
        soldTo: 2
    }]
}, {
    id: 2,
    name: "Anne",
    email: "anne@company.com",
    products: [{
        id: 3,
        description: "Teclado mecánico",
        price: 25,
        soldTo: 1
    },{
        id: 4,
        description: "Raqueta de tenis",
        price: 62.50,
        soldTo: 4
    },{
        id: 5,
        description: "Telescopio",
        price: 132,
        soldTo: 3
    }]
}, {
    id: 3,
    name: "John",
    email: "john@hotmail.com",
    products: [{
        id: 6,
        description: "Ratón láser",
        price: 15,
        soldTo: 1
    },{
        id: 7,
        description: "Silla rota",
        price: 3.40,
    },{
        id: 8,
        description: "Figura de Terminator 2",
        price: 80,
    }]
}, {
    id: 4,
    name: "Frank",
    email: "franky@qwerty.com",
    products: [{
        id: 9,
        description: "Cuadro de unicornio rosa",
        price: 75,
        soldTo: 2
    },{
        id: 10,
        description: "Cepillo eléctrico",
        price: 12.50,
    },{
        id: 11,
        description: "Ultra home cinema 9.2",
        price: 235,
        soldTo: 3
    },{
        id: 12,
        description: "Tostadora",
        price: 32.50,
        soldTo: 1
    },{
        id: 13,
        description: "Batería de portátil",
        price: 25,
        soldTo: 1
    }]
}];
